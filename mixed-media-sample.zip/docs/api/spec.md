# API Specification

## Endpoints

### GET /api/artifacts
Returns a list of artifacts.

### POST /api/artifacts
Creates a new artifact.

_This file demonstrates nested folder navigation._
